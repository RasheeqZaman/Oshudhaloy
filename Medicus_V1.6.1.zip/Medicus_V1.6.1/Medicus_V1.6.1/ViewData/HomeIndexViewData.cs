﻿using Medicus_V1._6._1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Medicus_V1._6._1.ViewData
{
    public class HomeIndexViewData
    {
        public List<Medicine> MedicineList { get; set; }
    }
}